package Database;

import models.Extra.messages.Message;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MyRequest {
    private static final Path DATA_DIRECTORY = Path.of("data");
    static final Path DATABASE_FILE = DATA_DIRECTORY.resolve("my_request.db");
    private static final String DATABASE_URL = "jdbc:sqlite:" + DATABASE_FILE;
    private static final String CREATE_REQUEST_TABLE_SQL = """
            CREATE TABLE IF NOT EXISTS my_request (
                STT INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT,
                id_user TEXT,
                request_type TEXT ,
                request_info TEXT,
                send_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP                               
            )
            """;

    public MyRequest(){
        try{
            initializeRequest_Log();

        } catch (SQLException | IOException e) {
            throw new IllegalStateException(" KHONG THE KHOI TAO request database");
        }
    }

    public static void save_myrequest(Message message, String requestId) throws  IOException {
        try(Connection connection = openConnection();
            PreparedStatement statement = connection.prepareStatement("""
            INSERT INTO my_request (request_id, id_user , request_type , request_info) VALUES (?, ? , ? , ?)""")
        ){
            statement.setString(1, requestId);
            statement.setString(2,message.Id_user);
            statement.setString(3,message.messageType);
            statement.setString(4, message.payloadJson);

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } ;
    }

    public List<RequestRecord> getMyRequestsByType(String requestType) throws IOException {
        try (Connection connection = openConnection();
             PreparedStatement statement = connection.prepareStatement("""
                     SELECT STT, request_id, id_user, request_type, request_info, send_at
                     FROM my_request
                     WHERE request_type = ?
                     ORDER BY send_at ASC
                     """)) {
            statement.setString(1, requestType);
            try (ResultSet resultSet = statement.executeQuery()) {
                List<RequestRecord> requests = new ArrayList<>();
                while (resultSet.next()) {
                    requests.add(new RequestRecord(
                            resultSet.getInt("STT"),
                            resultSet.getString("request_id"),
                            resultSet.getString("id_user"),
                            resultSet.getString("request_type"),
                            resultSet.getString("request_info"),
                            resultSet.getString("send_at")
                    ));
                }
                return requests;
            }
        } catch (SQLException e) {
            throw new IOException("Khong the lay danh sach request", e);
        }
    }

    public void deleteMyRequests(List<Integer> requestIds) throws IOException {
        if (requestIds == null || requestIds.isEmpty()) {
            return;
        }

        try (Connection connection = openConnection();
             PreparedStatement statement = connection.prepareStatement("""
                     DELETE FROM my_request
                     WHERE STT = ?
                     """)) {
            for (Integer requestId : requestIds) {
                statement.setInt(1, requestId);
                statement.addBatch();
            }
            statement.executeBatch();
        } catch (SQLException e) {
            throw new IOException("Khong the xoa request", e);
        }
    }

    private void initializeRequest_Log() throws IOException, SQLException {
        ensureDataDirectoryExists();
        try(Connection conn = openConnection();
            Statement statement = conn.createStatement()){
            statement.executeUpdate(CREATE_REQUEST_TABLE_SQL);
        }
    }
    private void ensureDataDirectoryExists() throws IOException {
        if (Files.notExists(DATA_DIRECTORY)) {
            Files.createDirectories(DATA_DIRECTORY);
        }
    }
    private static Connection openConnection() throws SQLException{
        return DriverManager.getConnection(DATABASE_URL);
    }

    public record RequestRecord(int id, String requestId, String userId, String requestType, String requestInfo,String time) {
    }
}
